﻿var config =  {
    title:"澳门新葡京",//站点名称
    tyLink_h5:"https://x957.com/m/#/home/type/10002?name=%E4%BD%93%E8%82%B2%E8%B5%9B%E4%BA%8B&id=10002",
    tyLink_pc:"https://x957.com/#/home/tiyu?id=0",
    zrLink_h5:"https://x957.com/m/#/home/type/10003?name=%E7%9C%9F%E4%BA%BA%E8%A7%86%E8%AE%AF&id=10003",
    zrLink_pc:"https://x957.com/#/home/live",
    qpLink_h5:"https://x957.com/m/#/home/type/10004?name=%E6%A3%8B%E7%89%8C%E6%B8%B8%E6%88%8F&id=10004",
    qpLink_pc:"https://x957.com/#/home/chess?navid=9&id=0",
    dzLink_h5:"https://x957.com/m/#/home/type/10001?name=%E7%94%B5%E5%AD%90%E6%B8%B8%E8%89%BA&id=10001",
    dzLink_pc:"https://x957.com/#/home/slot?navid=9&id=0",
    cpLink_h5:"https://x957.com/m/#/home/type/10000?name=%E5%BD%A9%E7%A5%A8%E6%B8%B8%E6%88%8F&id=10000",
    cpLink_pc:"https://x957.com/#/plays/hall",
    tzLink_h5:"https://x957.com/m/#/home",
    tzLink_pc:"https://x957.com",
    // 公告
    notice: "澳门新葡京x957.com 赌场直营，大额无忧，让每个人都能在这里找到最完美的体验！新注册专属优惠，联系在线客服获取!",

};
