if (/AppleWebKit.*Mobile/i.test(navigator.userAgent) || /Android/i.test(navigator.userAgent) || /BlackBerry/i.test(navigator.userAgent) || /IEMobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))) {
    window.location.href = "mobile/index.html"
};
function gopath(a) {
    let url;
    if (a == 1) url = 'https://lin.ee/QQ1dK9i';
    else if (a == 2) url = 'https://vue.livelyhelp.chat/chatWindow.aspx?siteId=60002210&planId=52f5469a-0d46-4787-a52a-5d5e4adb225d#';
    else url = 'https://www.thsands2.com/';
    window.location.href = url
}